#!/data/data/com.termux/files/usr/bin/bash
set -e
pkg update -y
pkg install nodejs -y
npm install
if [ ! -f .env ]; then cp .env.example .env; fi
echo
echo "NEXORA AI installed."
echo "Start it with: npm start"
echo "Then open Chrome: http://127.0.0.1:3000"
