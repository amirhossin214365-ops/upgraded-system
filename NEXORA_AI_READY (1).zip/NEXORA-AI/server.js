require("dotenv").config();
const express = require("express");
const path = require("path");

const app = express();
const PORT = Number(process.env.PORT || 3000);
const HOST = process.env.HOST || "0.0.0.0";

app.use(express.json({ limit: "2mb" }));
app.use(express.static(path.join(__dirname, "public")));

app.get("/api/health", (_req, res) => {
  res.json({ ok: true, name: "NEXORA AI", aiConfigured: Boolean(process.env.AI_BASE_URL && process.env.AI_API_KEY && process.env.AI_MODEL) });
});

app.post("/api/chat", async (req, res) => {
  const message = String(req.body?.message || "").trim();
  const history = Array.isArray(req.body?.history) ? req.body.history.slice(-12) : [];
  if (!message) return res.status(400).json({ error: "پیام خالی است." });

  const base = process.env.AI_BASE_URL;
  const key = process.env.AI_API_KEY;
  const model = process.env.AI_MODEL;

  if (base && key && model) {
    try {
      const endpoint = base.replace(/\/+$/, "") + "/chat/completions";
      const response = await fetch(endpoint, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${key}`
        },
        body: JSON.stringify({
          model,
          messages: [
            { role: "system", content: "You are NEXORA AI, a helpful assistant. Reply in the user's language, Persian or English. Be clear, accurate, and age-appropriate." },
            ...history.filter(x => ["user", "assistant"].includes(x.role)).map(x => ({ role: x.role, content: String(x.content || "").slice(0, 4000) })),
            { role: "user", content: message }
          ],
          temperature: 0.7
        })
      });
      const data = await response.json();
      if (!response.ok) return res.status(502).json({ error: data?.error?.message || `AI provider returned ${response.status}` });
      const reply = data?.choices?.[0]?.message?.content;
      if (!reply) return res.status(502).json({ error: "پاسخ معتبری از سرویس هوش مصنوعی دریافت نشد." });
      return res.json({ reply, mode: "ai" });
    } catch (err) {
      return res.status(502).json({ error: "اتصال به سرویس هوش مصنوعی برقرار نشد: " + err.message });
    }
  }

  const lower = message.toLowerCase();
  let reply;
  if (/سلام|درود|hello|hi\b/.test(lower)) {
    reply = "سلام! من NEXORA AI هستم. رابط برنامه آماده است. برای فعال‌شدن پاسخ‌گویی هوش مصنوعی واقعی، یک سرویس سازگار با OpenAI را در فایل .env تنظیم کن.";
  } else if (/راهنما|help|چطور/.test(lower)) {
    reply = "می‌توانی از بخش‌های چت، آموزش، صدا، جست‌وجو و تصویر استفاده کنی. در حالت نمایشی، چت بدون اتصال به مدل هوش مصنوعی کار می‌کند؛ برای پاسخ‌های هوشمند واقعی باید تنظیمات AI در فایل .env تکمیل شود.";
  } else {
    reply = "پیامت را دریافت کردم: «" + message + "»\n\nدر حال حاضر NEXORA در حالت نمایشی است. برای دریافت پاسخ هوش مصنوعی واقعی، مقدارهای AI_BASE_URL، AI_API_KEY و AI_MODEL را در فایل .env وارد کن و سرور را دوباره اجرا کن.";
  }
  res.json({ reply, mode: "demo" });
});

app.get("/api/search", async (req, res) => {
  const q = String(req.query.q || "").trim();
  if (!q) return res.status(400).json({ error: "عبارت جست‌وجو را وارد کن." });
  try {
    const url = "https://api.duckduckgo.com/?q=" + encodeURIComponent(q) + "&format=json&no_html=1&skip_disambig=1";
    const r = await fetch(url, { headers: { "User-Agent": "NEXORA-AI/1.0" } });
    const data = await r.json();
    const items = [];
    if (data.AbstractText) items.push({ title: data.Heading || q, text: data.AbstractText, url: data.AbstractURL || "" });
    for (const item of (data.RelatedTopics || [])) {
      if (item.Text && item.FirstURL) items.push({ title: item.Text.split(" - ")[0], text: item.Text, url: item.FirstURL });
      if (item.Topics) for (const sub of item.Topics) if (sub.Text && sub.FirstURL) items.push({ title: sub.Text.split(" - ")[0], text: sub.Text, url: sub.FirstURL });
      if (items.length >= 8) break;
    }
    res.json({ query: q, items, note: items.length ? "" : "برای این عبارت پاسخ فوری پیدا نشد؛ جست‌وجوی وب را باز کن." });
  } catch {
    res.status(502).json({ error: "جست‌وجو در حال حاضر در دسترس نیست. اتصال اینترنت را بررسی کن." });
  }
});

app.get("*", (_req, res) => res.sendFile(path.join(__dirname, "public", "index.html")));

app.listen(PORT, HOST, () => {
  console.log(`NEXORA AI running at http://127.0.0.1:${PORT}`);
});
