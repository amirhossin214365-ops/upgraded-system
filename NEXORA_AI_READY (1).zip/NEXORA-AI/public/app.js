const $ = s => document.querySelector(s);
const messages = [];
function addMessage(role, content) {
  const box = document.createElement("div");
  box.className = "message " + role;
  const who = document.createElement("div"); who.className = "who";
  who.textContent = role === "user" ? "شما" : "NEXORA AI";
  const body = document.createElement("div"); body.textContent = content;
  box.append(who, body); $("#messages").append(box); box.scrollIntoView({behavior:"smooth",block:"end"});
}
async function sendChat(text) {
  if (!text.trim()) return;
  addMessage("user", text); messages.push({role:"user",content:text});
  const wait = document.createElement("div"); wait.className="message assistant"; wait.textContent="NEXORA در حال آماده‌سازی پاسخ..."; $("#messages").append(wait);
  try {
    const r = await fetch("/api/chat",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({message:text,history:messages.slice(-10,-1)})});
    const data = await r.json(); wait.remove();
    const reply = data.reply || data.error || "پاسخی دریافت نشد.";
    addMessage("assistant", reply); messages.push({role:"assistant",content:reply});
  } catch { wait.remove(); addMessage("assistant","ارتباط با سرور برقرار نشد. بررسی کن سرور ترموکس روشن باشد."); }
}
$("#chatForm").addEventListener("submit",e=>{e.preventDefault();const t=$("#chatInput").value;$("#chatInput").value="";sendChat(t)});
$("#chatInput").addEventListener("keydown",e=>{if(e.key==="Enter"&&!e.shiftKey){e.preventDefault();$("#chatForm").requestSubmit()}});
document.querySelectorAll(".quick").forEach(b=>b.addEventListener("click",()=>sendChat(b.dataset.prompt)));
function showPage(name){document.querySelectorAll(".page").forEach(p=>p.classList.toggle("active",p.id==="page-"+name));document.querySelectorAll(".nav-item").forEach(b=>b.classList.toggle("active",b.dataset.page===name));$("#sidebar").classList.remove("open")}
document.querySelectorAll(".nav-item").forEach(b=>b.addEventListener("click",()=>showPage(b.dataset.page)));
$("#newChat").addEventListener("click",()=>{$("#messages").innerHTML="";messages.length=0;showPage("chat")});
$("#menuBtn").addEventListener("click",()=>$("#sidebar").classList.toggle("open"));
$("#language").addEventListener("change",e=>{document.documentElement.lang=e.target.value;document.documentElement.dir=e.target.value==="fa"?"rtl":"ltr"});
$("#learnBtn").addEventListener("click",()=>{const t=$("#learnTopic").value.trim();if(t){showPage("chat");sendChat("مثل یک معلم، موضوع «"+t+"» را مرحله‌به‌مرحله با مثال و تمرین آموزش بده.")}});
$("#searchForm").addEventListener("submit",async e=>{e.preventDefault();const q=$("#searchInput").value.trim();$("#searchResults").textContent="در حال جست‌وجو...";try{const r=await fetch("/api/search?q="+encodeURIComponent(q));const d=await r.json();$("#searchResults").innerHTML="";(d.items||[]).forEach(x=>{const el=document.createElement("article");el.className="result";const a=document.createElement("a");a.href=x.url;a.target="_blank";a.rel="noopener";a.textContent=x.title||x.url;const p=document.createElement("p");p.textContent=x.text;el.append(a,p);$("#searchResults").append(el)});if(!d.items?.length){const p=document.createElement("p");p.className="muted-text";p.textContent=d.note||d.error||"نتیجه‌ای پیدا نشد.";$("#searchResults").append(p)} }catch{$("#searchResults").textContent="جست‌وجو ناموفق بود."}});
$("#imageInfo").addEventListener("click",()=>{const t=$("#imagePrompt").value.trim();if(t){navigator.clipboard?.writeText(t);$("#imageStatus").textContent="توضیح تصویر آماده شد و در صورت پشتیبانی مرورگر کپی شد: "+t}});
let recognition;
$("#listenBtn").addEventListener("click",()=>{const SR=window.SpeechRecognition||window.webkitSpeechRecognition;if(!SR){$("#voiceStatus").textContent="تشخیص گفتار در این مرورگر پشتیبانی نمی‌شود. از Chrome و اتصال امن/مجوز میکروفون استفاده کن.";return}recognition=new SR();recognition.lang=$("#language").value==="fa"?"fa-IR":"en-US";recognition.interimResults=false;recognition.onresult=e=>{$("#voiceText").value=e.results[0][0].transcript;$("#voiceStatus").textContent="گفتار دریافت شد."};recognition.onerror=()=>$("#voiceStatus").textContent="دریافت صدا ناموفق بود؛ مجوز میکروفون را بررسی کن.";recognition.start();$("#voiceStatus").textContent="در حال گوش‌دادن..."});
$("#sendVoice").addEventListener("click",()=>{const t=$("#voiceText").value.trim();if(t){showPage("chat");sendChat(t)}});
$("#speakText").addEventListener("click",()=>{const t=$("#voiceText").value.trim();if(t&&"speechSynthesis"in window){speechSynthesis.cancel();const u=new SpeechSynthesisUtterance(t);u.lang=$("#language").value==="fa"?"fa-IR":"en-US";speechSynthesis.speak(u)}});
let audioCtx, oscillator, gain;
$("#toneStart").addEventListener("click",async()=>{try{audioCtx ||= new (window.AudioContext||window.webkitAudioContext)();await audioCtx.resume();if(oscillator)oscillator.stop();oscillator=audioCtx.createOscillator();gain=audioCtx.createGain();oscillator.type="sine";oscillator.frequency.value=220;gain.gain.value=.035;oscillator.connect(gain);gain.connect(audioCtx.destination);oscillator.start()}catch{}});
$("#toneStop").addEventListener("click",()=>{if(oscillator){oscillator.stop();oscillator=null}});
fetch("/api/health").then(r=>r.json()).then(d=>{$("#connectionLabel").textContent=d.aiConfigured?"اتصال هوش مصنوعی تنظیم شده":"سرور روشن · حالت نمایشی";}).catch(()=>$("#connectionLabel").textContent="اتصال سرور بررسی نشد");
if("serviceWorker"in navigator)window.addEventListener("load",()=>navigator.serviceWorker.register("/sw.js").catch(()=>{}));
